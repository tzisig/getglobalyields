---
slug: joint-accounts-estate-tax-exposure
title: "Joint Accounts and US Estate Tax Exposure"
description: "Adding a spouse as joint owner on a US brokerage account feels like it splits estate tax exposure. For non-citizen couples, the real rule is far less favorable."
pubDate: 2026-10-11
updatedDate: 2026-08-06
author: "Tzion Sigron"
categories: ["Estate Planning"]
tags:
  - "joint account estate tax non-citizen spouse"
  - "joint tenancy brokerage account estate tax"
  - "mixed nationality couple estate tax US"
heroImage: "/images/blog/estate-planning/joint-accounts-estate-tax-exposure.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: true
readingTime: "10 min read"
featured: false
---

Adding a spouse as a joint owner on a brokerage account feels intuitively like it should split the account's value between two estates for tax purposes - each spouse's estate on the hook for roughly half. For a couple where at least one spouse is not a US citizen, the actual rule is meaningfully less favorable than that intuition, and worth understanding clearly before assuming joint ownership provides the protection it seems like it should.

---

## The Rule for US Citizen Couples (For Comparison)

When both spouses are US citizens, joint tenancy with right of survivorship generally results in half the account's value being included in the first-to-die spouse's estate - a reasonably intuitive split. Combined with the unlimited marital deduction available between US citizen spouses, this typically doesn't create a US estate tax problem for citizen couples regardless of the split, since the surviving citizen spouse's inheritance is fully shielded regardless of how much of the account was technically included in the deceased spouse's estate.

---

## The Rule That Actually Applies to Mixed-Nationality Couples

**If the surviving spouse is not a US citizen, the general rule is dramatically different: the full value of a jointly held account is included in the first-to-die spouse's estate - not half - unless the estate's executor can substantiate the surviving (non-citizen) spouse's own actual contributions toward acquiring the property.**

This is a real, specific rule (sometimes called the "back-tracing" requirement), and it applies to brokerage accounts held as joint tenants with right of survivorship exactly as it applies to other jointly held property. Without documentation proving the non-citizen spouse's contributions, the full account value - not the intuitive half - counts against the deceased spouse's estate.

---

## A Worked Illustration of the Gap

**Consider a mixed-nationality couple who jointly hold a $500,000 US brokerage account, where the US citizen spouse contributed all the funds and dies first.** Under the intuitive assumption, one might expect $250,000 (half) to be included in the deceased citizen spouse's estate. Under the actual back-tracing rule, since the non-citizen spouse contributed nothing that can be substantiated, the full $500,000 is included in the deceased spouse's estate instead.

**Why this specific gap matters practically:** a US citizen decedent has access to the large citizen exemption, so this particular estate likely wouldn't face US estate tax regardless of whether $250,000 or $500,000 is technically included - the deceased citizen spouse's own exemption comfortably covers either figure. **Note which way the rule cuts, because it is easy to get backwards.** Inclusion follows *who furnished the money*, not who died. If the citizen spouse funded the account and the non-citizen spouse dies first, the non-citizen furnished nothing - so little or nothing is includible in their estate. The rule works in the couple's favour in that direction.

**The genuinely dangerous case is the one where the non-citizen spouse both funded the account and dies first.** Then the full $500,000 is included in an estate with a $60,000 exemption, and the bill is real:

| Step | Amount |
|---|---|
| Included in the NRA's estate | $500,000 |
| Tentative tax under the §2001(c) schedule | $155,800 |
| Less the §2102(b) unified credit | −$13,000 |
| **US estate tax due** | **$142,800** |

There is no unlimited marital deduction to fall back on, because the surviving spouse is not a US citizen - which is precisely what the QDOT below is for. A couple who assumed the "half the account" intuition would have planned for a fraction of that.

---

## Why the Marital Deduction Doesn't Fix This Either

For US citizen couples, an unlimited marital deduction generally shelters property passing to a surviving spouse from estate tax entirely, regardless of joint ownership questions. **This unlimited marital deduction is only available when the surviving spouse is a US citizen.** If the surviving spouse is not a US citizen - even if a US resident - the unlimited marital deduction does not apply, removing the safety net that would otherwise make the joint-ownership inclusion question less consequential. This is precisely why the back-tracing rule and the marital deduction limitation compound into a genuinely serious combined risk for mixed-nationality couples specifically, in a way neither issue alone would create.

**A specific structure - a Qualified Domestic Trust (QDOT) - exists to address this gap for non-citizen surviving spouses**, allowing some marital deduction benefit if property passes through a properly structured QDOT rather than outright to the surviving spouse. This is genuinely specialized planning, not a technique to implement without a cross-border estate planning attorney, but worth knowing exists as an option if this situation applies to you - a QDOT can meaningfully soften the impact of the missing unlimited marital deduction, though it comes with its own structural requirements and ongoing administration.

---

## Documenting Contributions - A Practical Step Worth Taking Now

**The back-tracing rule's escape hatch - substantiating the non-citizen spouse's own actual contributions - only works if documentation actually exists.** A couple relying on this defense years or decades after the fact, without contemporaneous records, may find it genuinely difficult to reconstruct exactly which spouse's funds contributed which portion of a joint account's value, particularly after years of combined contributions, reinvested dividends, and market growth blending the original contributions together.

**A practical step worth taking now, regardless of your couple's current risk level:** maintain clear records of each spouse's contributions to any jointly held account from the outset, rather than assuming this can be reconstructed later if it ever becomes relevant. This is a low-cost, low-effort step today that can matter enormously if the less-favorable rule ever applies to your specific situation.

---

## Who This Actually Affects

This is directly relevant to the mixed-nationality couples that are genuinely common among the international investor audience this site serves - one spouse holding US citizenship (or being a US person for tax purposes) while the other doesn't, jointly holding a US brokerage account together. **Simply assuming that joint ownership "splits" the exposure, the way it would for two US citizen spouses, can significantly understate the actual estate tax risk if the non-citizen-adjacent spouse dies first, or if the couple hasn't documented contributions carefully.**

---

## Joint Accounts and US Estate Tax Exposure - The Questions Left Over

**Does this rule apply the same way to unmarried couples holding a joint account?**
The specific spousal marital deduction and QDOT provisions discussed in this guide are marriage-specific; unmarried joint account holders face a related but distinct set of considerations under general joint tenancy and gift tax rules, worth addressing separately with a cross-border estate planning attorney rather than assuming the spousal-specific rules in this guide apply directly.

**Does opening separate, individually-owned accounts instead of a joint account avoid this issue entirely?**
This is one option worth considering specifically because of the back-tracing complexity - separate accounts, each held individually, avoid the joint-ownership inclusion question entirely, since each account's ownership and contribution history is unambiguous by design. This trades away certain conveniences of joint ownership (like automatic survivorship) for clarity on the estate tax question, a trade-off worth discussing with your advisor given your specific goals.

**If the non-citizen spouse becomes a US citizen before the citizen spouse dies, does that change the analysis?**
Yes, potentially significantly - since the unlimited marital deduction and the more favorable joint-ownership rules become available once both spouses are US citizens, a change in citizenship status can meaningfully improve the situation, worth discussing with an estate planning attorney if citizenship is a realistic path being considered for other reasons.

**Does this rule apply to jointly held real estate or other assets, or only brokerage accounts?**
The back-tracing rule and marital deduction limitation are general principles applying to jointly held property between a citizen and non-citizen spouse, not specific to brokerage accounts alone - though this guide focuses on brokerage accounts specifically given this site's focus, the same underlying rules extend to other jointly held US-situs property.

---

## What to Actually Do About Joint Accounts and US Estate Tax Exposure

- [ ] If you're in a mixed-nationality couple with a jointly held US brokerage account, do not assume joint ownership automatically splits estate tax exposure the way it would for two US citizen spouses
- [ ] Keep clear, contemporaneous documentation of each spouse's actual financial contributions to the joint account, since this is what determines whether the non-citizen spouse's contribution can be substantiated and excluded from the full-inclusion rule
- [ ] Confirm whether a Qualified Domestic Trust (QDOT) or similar structure is relevant to your situation if the surviving spouse would not be a US citizen
- [ ] Consider whether separate, individually-owned accounts might better serve your situation than a joint account, given the back-tracing complexity
- [ ] Get cross-border estate planning advice specifically addressing your couple's citizenship mix - this is a genuinely different analysis from either a fully-US-citizen or fully-non-US couple's situation

---

## Closing the Loop on Joint Accounts and US Estate Tax Exposure

For a mixed-nationality couple, joint ownership of a US brokerage account does not provide the intuitive "half the exposure" protection that applies between two US citizen spouses - without documented proof of the non-citizen spouse's own contributions, the full account value can be included in the first-to-die spouse's estate, with no unlimited marital deduction available to offset it. This is one of the more consequential, and least intuitive, rules covered in this category, and worth addressing proactively - through careful documentation, a QDOT structure, or separate accounts - rather than discovering after the fact.

---

*Educational content about Joint Accounts and US Estate Tax Exposure; it carries no advice for your case. Joint ownership and marital deduction rules for mixed-nationality couples are complex and fact-specific. Have a qualified professional weigh this against your situation.*

*Sources: IRC §2102(b) ($60,000 exemption equivalent for non-resident aliens); IRS Form 706-NA instructions. On a joint tenancy with right of survivorship the IRS presumes the full account belonged to the first decedent unless the survivor can evidence their own contribution - which is what drives the outcome in the worked example above.*

---

## Related Guides

- [US Estate Tax for Non-Resident Aliens: The $60,000 Exemption Trap](/estate-planning/us-estate-tax-non-resident-aliens-60000-exemption/)
- [Avoiding US Estate Tax on a Brokerage Account](/estate-planning/avoiding-us-estate-tax-brokerage-account/)
- [Transfer on Death Designations for Foreign Investors](/estate-planning/tod-designations-foreign-investors/)
