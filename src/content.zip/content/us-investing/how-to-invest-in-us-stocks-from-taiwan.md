---
slug: how-to-invest-in-us-stocks-from-taiwan
title: "How to Invest in US Stocks from Taiwan (2026 Guide)"
description: "How to Invest in US Stocks from Taiwan: why there's no tax treaty (a diplomatic-recognition issue), the pending H.R. 33 bill, and the 30% withholding reality."
pubDate: 2026-09-15
updatedDate: 2026-08-05
author: "Tzion Sigron"
categories: ["US Investing"]
tags:
  - "invest in US stocks from Taiwan"
  - "Taiwan ETF investing 2026"
  - "H.R. 33 Taiwan"
  - "Interactive Brokers Taiwan"
  - "IBKR Taiwan"
  - "eToro Taiwan"
  - "W-8BEN Taiwan"
  - "best broker Taiwan"
heroImage: "/images/blog/us-investing/how-to-invest-in-us-stocks-from-taiwan.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: true
readingTime: "10 min read"
featured: false
---

Taiwan is the largest US trading partner with no income tax treaty - not because negotiations failed, but because the US does not maintain formal diplomatic relations with Taiwan, and ordinary tax treaties require exactly that kind of government-to-government recognition. For a Taiwanese investor, the practical result is the same as any other no-treaty country: the full 30% US withholding applies to dividends.

This guide covers that reality, the pending legislation that would change it, and what you can buy in the meantime.

Everything here is verified from official sources for 2026.

---

<!-- ADSENSE PLACEHOLDER: TOP OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: HEADER_BANNER] -->

---

## Meet Wei-Ting

Wei-Ting is 30, lives in Taipei, and works in semiconductor supply chain management. He has TWD 900,000 to invest in US equities and has heard there is no US-Taiwan tax treaty, which he assumes is an oversight or a stalled negotiation. It is neither - the reason is structural, and there is a specific piece of pending US legislation worth knowing about while he plans around the current rules.

---

## Step 1: Why There's No Treaty - And What H.R. 33 Would Do

Ordinary US tax treaties are negotiated government-to-government and ratified by the Senate. Because the US does not formally recognize Taiwan as a sovereign state, that process is not available - so Congress has pursued a legislative workaround instead: a US law that would grant treaty-like relief without requiring a formal bilateral treaty.

**The US-Taiwan Expedited Double-Tax Relief Act (H.R. 33)** passed the House of Representatives on January 15, 2025, by a landslide 423-1 vote. It would authorize a **15% rate on dividends** (reducible to 10% for qualifying 10%+ ownership) and 10% on most other covered income types, down from the current 30% default.

**As of this update, H.R. 33 has not been enacted into law.** It cleared the House with overwhelming support but has not completed the remaining legislative steps needed to take effect, and there is no guaranteed timeline. If other sources describe different rates, check the date - this is a live legislative situation, and the correct current answer is that the 30% default still applies.

**What the gap actually costs in practice:** on a $3,000 annual US dividend income stream, the difference between the current 30% default and H.R. 33's proposed 15% rate is $450 a year - a meaningful, ongoing cost for as long as the legislation remains pending, not a one-time or trivial amount. This is worth keeping in perspective when deciding how much to invest in individual dividend-paying US stocks versus lower-yielding growth-oriented positions while the current 30% rate remains in effect, since the withholding drag is proportional to dividend income specifically, not to capital appreciation.

For the full picture, see our [US-Taiwan tax treaty guide](/taxes/us-taiwan-tax-treaty-investors/).

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE] -->

---

## Step 2: What's Purchasable From Taiwan

Taiwan is neither EU nor EEA, so the disclosure rule that shuts European buyers out of US-domiciled ETFs is not in force here. **Wei-Ting can buy VOO, VTI, and QQQ directly** through a broker offering US market access.

---

## Step 3: Until H.R. 33 Passes - The 30% Default

Without treaty-like relief in force, dividends from US stocks are withheld at the full **30%**, regardless of how Form [W-8BEN](/taxes/w8ben-form-non-us-investors/) is completed - the form still certifies non-US person status and prevents the backup withholding regime from applying - a lower 24% rate, but one that can reach gross sale proceeds, not just dividends, but there is no reduced rate to claim yet.

**Capital gains:** the US generally does not tax capital gains realized by a non-resident alien on US securities under domestic law, independent of treaty status - this part is unaffected by whether H.R. 33 eventually passes.

**Taiwan's side:** Taiwanese tax residents are taxed on worldwide income, including foreign dividends and capital gains from US stocks, though the interaction between Taiwan's Basic Income Tax (a form of alternative minimum tax capturing certain offshore income) and ordinary income tax rules can be fact-specific. Given both the pending US legislation and Taiwan's own offshore-income rules, current, personalized advice from a Taiwanese tax advisor is worth more than a general guide here.

---

## Step 4: Picking the Platform From Taiwan

Taiwanese residents are eligible at both **Interactive Brokers (IBKR)** and **eToro**. [See our full IBKR review →](/best-brokers/interactive-brokers-review-2026-the-best-broker-for-international-investors/) · [See our full eToro review →](/best-brokers/etoro-review-2026/)

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE 2 -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE_2] -->

---

## Step 5: What Wei-Ting's Portfolio Looks Like in Practice

**Broker:** Interactive Brokers - cheaper to run once contributions are regular.

**Portfolio allocation:**
- 100% VOO (S&P 500, bought directly)
- Wei-Ting deliberately skips QQQ: his salary already tracks the semiconductor cycle, and the Nasdaq-100's largest weights would stack a second helping of the same risk on top of his career
- W-8BEN filed to certify status and avoid backup withholding, even without a rate benefit yet

**Annual tax situation:**
- 30% US withholding on dividends - the current fixed reality until H.R. 33 changes it
- Worldwide income, including US investment income, reported under Taiwan's tax framework, with Basic Income Tax interactions confirmed by his tax advisor

He bookmarks the status of H.R. 33 and plans to revisit his withholding expectations if and when it becomes law, since the rate could drop meaningfully without any action needed on his part beyond re-confirming his W-8BEN is current.

---

<!-- ADSENSE PLACEHOLDER: NEAR END OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: BOTTOM_CONTENT_RECTANGLE] -->

---

## Where Investors Slip Up on Taiwan

**Assuming H.R. 33 is already in effect.** It passed the House but is not yet law - the 30% default still applies.

**Skipping W-8BEN because there's no rate benefit yet.** It still matters for avoiding backup withholding, and having it on file means you are ready the moment relief takes effect.

**Assuming the lack of a treaty reflects a failed negotiation.** It is a diplomatic-recognition issue, not a negotiation failure - worth understanding to avoid confusion when comparing Taiwan to genuinely no-treaty countries.

---

## What to Do First From Taiwan

1. **Open a broker account.** IBKR or eToro, both confirmed to accept Taiwanese residents.
2. **File your W-8BEN** to certify your status and avoid backup withholding.
3. **Buy VOO or QQQ as listed** - no UCITS wrapper stands in the way.
4. **Check the status of H.R. 33 periodically** - of everything covered on this site, this is one of the situations most likely to improve materially in the near term.

---

*Everything here about Taiwan is educational, not personalised advice. There is no comprehensive income tax treaty between the United States and Taiwan as of this update; H.R. 33 passed the House on January 15, 2025, but has not been enacted into law. Consult a qualified Taiwanese tax advisor for advice specific to your situation.*

---

<!-- AFFILIATES PLACEHOLDER: BROKER CTA SECTION -->
<!-- Place immediately below the disclaimer -->
<!-- [AFFILIATE_UNIT: BROKER_COMPARISON_TABLE_TAIWAN] -->
<!-- Anchor text: "Compare the best brokers for Taiwanese investors in 2026 - fees, account access, and ETF availability." -->
<!-- Link to: /best-brokers/best-brokers-international-investors-2026/ (no Taiwan-specific page exists yet) -->

---

## The Taiwan Questions People Actually Ask

**Why doesn't Taiwan have a US tax treaty?**
Because the US does not formally recognize Taiwan as a sovereign state, the standard government-to-government treaty process is not available - not because negotiations failed. Congress has instead pursued H.R. 33, a legislative workaround, currently pending.

**What's the current US withholding rate on my dividends?**
30%, the full default, since no treaty-like relief is currently in force. H.R. 33 would reduce this to 15% (or 10% for qualifying corporate ownership) if enacted, but it has not yet become law.

**Should I still file W-8BEN if it doesn't reduce my rate?**
Yes. It certifies your non-US person status and avoids backup withholding, and having it on file means you are ready immediately if H.R. 33 passes.

**Can I buy VOO and QQQ directly as a Taiwanese investor?**
Yes. Taiwan is not an EU or EEA jurisdiction, so no PRIIPs restriction stands between you and US-listed funds.

**Which brokers accept Taiwanese residents?**
Interactive Brokers and eToro are both confirmed to accept Taiwanese residents for account opening.

---

*Sources: IRS Publication 515 (2026) and IRS tax treaty tables (no Taiwan listing); IRC §871 (non-resident alien taxation); RSM - House Passes US-Taiwan Expedited Double-Tax Relief Act With Bipartisan Support; House Ways and Means Committee - Summary of the United States-Taiwan Expedited Double-Tax Relief Act; Congress.gov - S. Rept. 118-107; Wolf & Company - Understanding the United States-Taiwan Expedited Double-Tax Relief Act; IRS Publication 515 (2026).*
