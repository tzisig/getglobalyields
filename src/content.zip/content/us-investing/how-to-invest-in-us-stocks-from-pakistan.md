---
slug: how-to-invest-in-us-stocks-from-pakistan
title: "How to Invest in US Stocks from Pakistan (2026 Guide)"
description: "How to Invest in US Stocks from Pakistan: the real barrier is State Bank capital controls, not tax rate. Broker options, W-8BEN, 10% treaty rate - for 2026."
pubDate: 2026-09-13
updatedDate: 2026-08-05
author: "Tzion Sigron"
categories: ["US Investing"]
tags:
  - "invest in US stocks from Pakistan"
  - "Pakistan ETF investing 2026"
  - "SBP foreign exchange"
  - "Interactive Brokers Pakistan"
  - "IBKR Pakistan"
  - "eToro Pakistan"
  - "W-8BEN Pakistan"
  - "best broker Pakistan"
heroImage: "/images/blog/us-investing/how-to-invest-in-us-stocks-from-pakistan.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: true
readingTime: "10 min read"
featured: false
---

Most guides to investing in US stocks lead with the tax rate. For Pakistan, that is not the right starting point. The US-Pakistan treaty delivers a genuinely favorable 10% dividend rate - but the question that actually determines whether this is practical for a Pakistani resident comes before tax entirely: can you legally move money out of Pakistan to fund a foreign brokerage account in the first place.

This guide covers that access question honestly, then the tax treatment once funds are in place.

Everything here is verified from official sources for 2026.

---

<!-- ADSENSE PLACEHOLDER: TOP OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: HEADER_BANNER] -->

---

## Meet Bilal

Bilal is 28, lives in Karachi, and works in IT consulting for a US-based client. He gets paid partly in USD and has heard about Interactive Brokers from online forums with real search interest from Pakistan. He assumes opening the account is the hard part. It is not - funding it through legal, authorized channels is the actual obstacle worth understanding first.

---

## Step 1: The Real Barrier - State Bank of Pakistan Capital Controls

Pakistan's foreign exchange regime operates under the Foreign Exchange Regulation Act (FERA), administered by the State Bank of Pakistan (SBP). **A Pakistani tax resident generally needs SBP approval to hold shares in a foreign company**, including funding a foreign brokerage account to buy US stocks. Foreign exchange transactions must go through authorized dealers, for permitted purposes, through SBP- and SECP-regulated channels. Using an unauthorized route to send money abroad for this purpose exposes a resident to real risk under FERA.

**This is a meaningfully tighter regime than most peer economies** covered elsewhere on this site - Pakistan's capital account controls on residents sending money abroad for portfolio investment are more restrictive than comparable South and Southeast Asian markets.

**One narrow, confirmed channel:** authorized dealers can open a Foreign Currency Value Account (FCVA) for a resident who already holds assets abroad, as declared on their latest wealth statement filed with the Federal Board of Revenue (FBR) - a route for regularizing and operating existing foreign holdings, not necessarily a general-purpose mechanism for a first-time transfer to open a brand-new foreign brokerage account.

**What could not be confirmed with certainty here:** a specific, current annual limit for a Pakistani resident to remit funds abroad specifically for opening or funding a foreign securities account through fully authorized channels. Given how consequential getting this wrong can be under FERA, **this is not something to guess at** - confirm the current, permitted route and any limit directly with an SBP-authorized dealer bank or a Pakistani foreign-exchange lawyer before transferring any meaningful amount.

**Bilal's specific situation - being paid partly in USD by a US-based client - raises its own separate question worth flagging.** Foreign-currency earnings received directly from abroad (rather than converted through the domestic banking system first) may follow different declaration and retention rules than funds an investor would otherwise need to actively remit from a Pakistani bank account - a genuinely different starting point than the "convert PKR and send it abroad" scenario most of this guide addresses. Whether USD income already held offshore, or received into a Pakistani foreign-currency account, can be more straightforwardly directed toward a foreign brokerage account than domestically-sourced PKR savings is exactly the kind of fact-specific question worth raising directly with an SBP-authorized dealer, since it could meaningfully simplify Bilal's specific funding path relative to a resident earning entirely in PKR.

For the full picture, see our [US-Pakistan tax treaty guide](/taxes/us-pakistan-tax-treaty-investors/).

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE] -->

---

## Step 2: Once Funded - What You Can Buy

Pakistan escapes PRIIPs altogether; that regime applies to EU and EEA residents, and is the reason they cannot buy US-domiciled ETFs. Once Bilal's account is legally funded, **he can buy VOO, VTI, and QQQ directly** through a broker offering US market access.

---

## Step 3: The Treaty - A Genuinely Good 10% on Dividends

Once funds are in place, the tax side is comparatively simple. The US-Pakistan tax treaty, dating to 1957, caps US withholding on dividends at **10%**, one of the more favorable rates covered on this site, claimed with Form [W-8BEN](/taxes/w8ben-form-non-us-investors/).

| Income Type | Default US Rate | Treaty Rate |
|---|---|---|
| Dividends | 30% | **10%** |
| Capital gains (securities) | Generally not US-taxable for non-residents | Residence country only |

No form, no treaty rate - 30% from the opening dividend onward.

**Pakistan's domestic side:** Pakistan taxes residents on worldwide income, including foreign-source dividends and capital gains, generally folded into normal taxable income under Pakistan's progressive individual income tax slabs rather than a separate flat rate. A foreign tax credit is available, capped at the lesser of the 10% US withholding paid or the Pakistani tax otherwise payable - confirm your specific bracket placement with a Pakistani tax advisor.

---

## Step 4: Which Broker Works From Pakistan

**Interactive Brokers (IBKR)** and **eToro** both show real, substantial search interest from Pakistan and are commonly cited as accepting Pakistani residents for account *opening*. **Opening the account and legally funding it from inside Pakistan are two separate questions** - confirm both independently, since account-opening being straightforward does not resolve the SBP capital-control question above. [See our full IBKR review →](/best-brokers/interactive-brokers-review-2026-the-best-broker-for-international-investors/) · [See our full eToro review →](/best-brokers/etoro-review-2026/)

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE 2 -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE_2] -->

---

## Step 5: What Bilal's Setup Looks Like in Practice

**Before opening anything:** Bilal contacts an SBP-authorized dealer bank to confirm the current permitted route and any limit for remitting funds abroad specifically to fund a foreign brokerage account - not assuming a general remittance allowance automatically covers this purpose.

**Broker:** Interactive Brokers, once funding is confirmed and legally in place.

**Portfolio allocation:**
- 100% VOO (S&P 500, bought directly), bought monthly as USD income arrives
- Bilal is already paid partly in dollars, so the constraint is the funding channel rather than the allocation - a single fund bought on a fixed monthly schedule keeps the paperwork per transfer to a minimum
- W-8BEN filed and confirmed active (10% withholding on his dividend statement)

**Annual tax situation:**
- 10% US withholding on dividends
- Dividends and capital gains folded into worldwide income on his Pakistani return, with a foreign tax credit for the US withholding already paid

He keeps documentation of the authorized channel he used to fund the account, in case it is ever needed to demonstrate compliance with FERA.

---

<!-- ADSENSE PLACEHOLDER: NEAR END OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: BOTTOM_CONTENT_RECTANGLE] -->

---

## What People Get Wrong About Pakistan

**Assuming account opening means you can fund it freely.** These are separate questions - confirm the SBP-authorized funding route before assuming access.

**Using an unauthorized channel to move money abroad.** FERA exposure is a real risk, not a formality.

**Skipping the SBP-authorized dealer conversation entirely.** This is genuinely not something to guess at, given the consequences of getting it wrong.

**Forgetting W-8BEN once funded.** A lodged W-8BEN is what activates the treaty on your account.

---

## Getting Started From Pakistan: The First Steps

1. **Contact an SBP-authorized dealer bank** to confirm the current permitted route and any limit for funding a foreign brokerage account - do this before anything else.
2. **If you already hold foreign assets on your FBR wealth statement**, ask whether an FCVA is the right structure for your situation.
3. **Open a broker account** with IBKR or eToro once the funding question is resolved.
4. **File your W-8BEN** to secure the 10% treaty rate.

---

*General information about Pakistan - not a recommendation you should act on unaided. Treaty rates are based on the US-Pakistan Income Tax Convention (1957). Pakistan's foreign exchange controls are administered by the State Bank of Pakistan under FERA and can change - confirm current rules with an SBP-authorized dealer and a qualified Pakistani tax and foreign-exchange advisor before transferring funds abroad.*

---

<!-- AFFILIATES PLACEHOLDER: BROKER CTA SECTION -->
<!-- Place immediately below the disclaimer -->
<!-- [AFFILIATE_UNIT: BROKER_COMPARISON_TABLE_PAKISTAN] -->
<!-- Anchor text: "Compare the best brokers for Pakistani investors in 2026 - fees, account access, and ETF availability." -->
<!-- Link to: /best-brokers/best-brokers-international-investors-2026/ (no Pakistan-specific page exists yet) -->

---

## Pakistan: Questions That Keep Coming Up

**Can I just open an Interactive Brokers account from Pakistan?**
Opening the account is generally straightforward - both IBKR and eToro are commonly cited as accepting Pakistani residents. Legally funding it from inside Pakistan is a separate question governed by State Bank of Pakistan capital controls, and needs to be confirmed independently.

**What's the US withholding rate on my dividends?**
10%, under the US-Pakistan tax treaty (1957), once Form W-8BEN is filed - one of the more favorable rates covered on this site. Without it, the default 30% applies.

**Do I need special approval to send money abroad to fund a US brokerage account?**
Generally yes. A Pakistani tax resident typically needs SBP approval or must use an authorized channel to hold foreign securities. Confirm the current permitted route with an SBP-authorized dealer bank before transferring funds.

**What is an FCVA and does it apply to me?**
A Foreign Currency Value Account is a confirmed channel for residents who already hold foreign assets declared on their FBR wealth statement. It is not necessarily the right mechanism for a first-time transfer to open a new foreign brokerage account - confirm with your bank.

**Can I buy VOO and QQQ directly once my account is funded?**
Yes. Pakistan is not subject to the EU's PRIIPs regulation, so any US-listed stock or ETF your broker offers is directly accessible once funds are legally in place.

---

*Sources: US-Pakistan Income Tax Convention (1957); IRS treaty tables; PwC Pakistan Corporate Withholding Taxes (2026); IRS Publication 515 (2026).*
