---
slug: how-to-invest-in-us-stocks-from-israel-step-by-step-2026
title: "How to Invest in US Stocks from Israel: Step-by-Step (2026)"
description: "How to invest in US stocks from Israel in 2026. Best brokers, W-8BEN setup, tax treaty benefits, capital gains rules, and step-by-step account opening guide."
pubDate: 2026-04-01
updatedDate: 2026-05-12
author: "Tzion Sigron"
categories: ["US Investing"]
tags:
  - "israel"
  - "us stocks"
  - "step-by-step"
  - "2026 guide"
  - "w-8ben"
  - "currency conversion"
  - "taxes"
heroImage: "/images/blog/us-investing/how-to-invest-in-us-stocks-from-israel-step-by-step-2026.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: false
readingTime: "15 min read"
featured: false
schema:
  faq:
    - question: "Is it legal for Israelis to invest in US stocks?"
      answer: "Yes, completely. Israeli residents are legally permitted to hold foreign investment accounts and invest in US stocks, ETFs, and other securities. There is no restriction on the amount you can invest abroad, provided you report your foreign income and assets to the Israeli Tax Authority as required."
    - question: "Which broker is best for Israeli investors in US stocks?"
      answer: "Interactive Brokers (IBKR) is the top choice for most Israeli investors. It accepts Israeli clients, offers excellent ILS-to-USD conversion rates at approximately 0.002%, and provides access to stocks, ETFs, options, and more."
    - question: "How do I fund an IBKR account from Israel?"
      answer: "Wire ILS from your Israeli bank to IBKR, then convert to USD inside the platform at IBKR's near-interbank rate. This is far cheaper than having your Israeli bank convert the currency. Most Israeli banks charge 30 to 80 ILS per international wire transfer."
    - question: "What is the W-8BEN rate for Israeli investors?"
      answer: "Israeli investors who file W-8BEN correctly receive a 25% withholding rate on US dividends under the US-Israel tax treaty, reduced from the default 30%."
    - question: "Do I need to pay tax in Israel on US stock gains?"
      answer: "Yes. Capital gains from selling US stocks are taxable in Israel at 25%. Dividends are also taxed at 25% in Israel, but the US withholding of 25% under the treaty means you generally do not pay double tax. You must report all foreign investment income on your Israeli annual tax return."
    - question: "What is the minimum deposit to start investing in US stocks from Israel?"
      answer: "Interactive Brokers has no minimum deposit. For beginners, starting with $1,000 to $5,000 is reasonable. To avoid the monthly inactivity fee, aim to generate at least $10 per month in commissions or grow your account to $100,000."
    - question: "Do I need to declare my IBKR account to the Bank of Israel?"
      answer: "There is no requirement to notify the Bank of Israel simply for opening a foreign brokerage account. However, you must report foreign assets and income to the Israeli Tax Authority as part of your annual tax obligations."
---

## **Introduction**

Investing in US stocks from Israel has never been more accessible. With the right broker and a basic understanding of the process, an Israeli investor can have a fully funded [US brokerage account](/best-brokers/how-to-open-a-us-brokerage-account-as-a-non-resident-2026-guide/) and place their first trade within a week.

Yet many Israelis are put off by the perceived complexity - foreign brokers, unfamiliar tax forms, currency conversion, and concerns about whether it is even legal. This guide answers all of those questions and walks you through the entire process from start to finish.

## **Is It Legal for Israelis to Invest in US Stocks?**

Yes, completely. Israeli residents are legally permitted to hold foreign investment accounts and invest in US stocks, ETFs, and other securities. There is no restriction on the amount you can invest abroad, provided you report your foreign income and assets to the Israeli Tax Authority (ITA) as required.

Key legal points:

-   You must report foreign investment accounts to the ITA if your holdings exceed certain thresholds
-   Dividends and capital gains from foreign investments are taxable in Israel
-   The US-Israel tax treaty governs how US [withholding tax](/taxes/taxes-us-dividends-foreign-investors/) interacts with your Israeli tax obligations
-   There is no requirement to use an Israeli broker - you can open an account directly with a US broker

## **Step 1: Choose Your Broker**

The first decision is which US broker to use. As an Israeli investor, your options are more limited than for US residents - many popular brokers like Robinhood, Fidelity, and Webull do not accept Israeli clients.

**[Interactive Brokers](/best-brokers/interactive-brokers-review-2026-the-best-broker-for-international-investors/) (IBKR) - Recommended:** The top choice for most Israeli investors. Accepts Israeli clients, offers excellent ILS-to-USD conversion rates, and provides access to stocks, ETFs, options, and more.

**[Tastytrade](/best-brokers/tastytrade-review-2026/):** Best if your focus is options trading - [covered calls](/options-income/selling-covered-calls-tqqq/), cash-secured puts, the [Wheel strategy](/options-income/wheel-strategy-tqqq/). Check current availability for Israeli clients on their website.

**[Firstrade](/best-brokers/firstrade-review-2026/):** A good starting point for beginners. Zero commissions across the board and a simpler interface.

Use our [Broker Finder](/resources/broker-finder/) to compare brokers that accept Israeli clients.

For most Israeli investors, Interactive Brokers is the default recommendation due to its ILS-to-USD conversion rates, which are significantly better than any Israeli bank.

## **Step 2: Gather Your Documents**

Before starting the application, prepare the following:

**Required for all brokers:**

-   Israeli passport (preferred) or Teudat Zehut
-   Proof of address: utility bill, bank statement, or official government letter dated within 90 days
-   Teudat Zehut number - your foreign tax identification number for the [W-8BEN](/taxes/w8ben-form-non-us-investors/) form
-   Israeli bank account details for funding and withdrawals

**Good to have ready:**

-   Israeli brokerage account statements (if any) - some brokers ask about investment experience
-   Basic information about your income and net worth

## **Step 3: Complete the Online Application**

The application process is fully online and takes 20 to 40 minutes. Here is what to expect:

**Personal information:** Name, date of birth, address, email, phone number

**Identity verification:** You will upload a photo of your passport and a selfie for identity matching. This is standard KYC procedure.

**Financial profile:** The broker will ask about your annual income, net worth, investment experience, and objectives. Answer honestly - this determines what products you can access.

**W-8BEN form:** Usually embedded in the application. Fill it in with your Israeli details (see Step 4 below).

**Agreement signing:** You will digitally sign the account agreement and various disclosures.

After submitting, approval typically takes 1 to 3 business days.

## **Step 4: Fill Out the W-8BEN Form**

The W-8BEN is the IRS form that certifies you are a foreign investor. It reduces your US dividend withholding tax from 30% to 25% under the US-Israel treaty.

For Israeli investors, fill it out as follows:

| **Field** | **What to Enter** |
| --- | --- |
| Line 1 - Name | Your full legal name (as on passport) |
| Line 2 - Country of citizenship | Israel |
| Line 3 - Permanent residence address | Your Israeli home address |
| Line 6 - Foreign tax ID | Your Teudat Zehut number |
| Line 9 - Treaty country | Israel |
| Line 10 - Rate | 25% (dividends under US-Israel treaty) |

Sign and date. The form is valid for 3 years - set a reminder to renew it.

## **Step 5: Fund Your Account**

Once your account is approved, you need to fund it. As an Israeli investor, you have two main options:

### **Option A: Wire ILS from Your Israeli Bank, Convert Inside IBKR (Recommended)**

You wire Israeli shekels from your Israeli bank account to IBKR, and then convert to USD inside the platform at IBKR's near-interbank rate (approximately 0.002% fee). This is far cheaper than having your Israeli bank convert the currency.

Steps:

-   In IBKR, go to Transfer and Pay > Transfer Funds > Deposit
-   Select Wire Transfer and choose ILS as the currency
-   IBKR will give you wire instructions including their bank details and your unique account reference number
-   Log in to your Israeli bank's online system and initiate an international wire transfer
-   Once the ILS arrives at IBKR (1 to 3 business days), use the currency conversion tool to convert ILS to USD

### **Option B: Wire USD Directly**

Some Israeli banks allow you to wire USD internationally. Your bank converts ILS to USD at their rate (typically 0.5% to 1.5% worse than IBKR's rate), and the USD arrives directly in your account. This is simpler but more expensive on the conversion.

**Wire transfer fees:** Most Israeli banks charge approximately 30 to 80 ILS per international wire transfer, plus potential correspondent bank fees.

## **Step 6: Navigate the Platform**

Once your account is funded, here is a quick orientation for new IBKR users:

### **Placing Your First Trade on IBKR Mobile**

-   Tap Trade
-   Search for the stock or ETF (e.g., type QQQ or TQQQ)
-   Select the security
-   Choose Buy
-   Enter the number of shares
-   Select order type: Limit Order (recommended) or Market Order
-   Review and submit

For beginners, always use a Limit Order rather than a Market Order. This prevents you from accidentally paying more than you intended, especially for less liquid securities.

## **Step 7: Understand Your Israeli Tax Obligations**

This is the step most guides skip - but it is essential for Israeli investors.

**What you must report to the Israeli Tax Authority:** Foreign investment income (dividends, interest) and capital gains from selling foreign securities must be reported on your Israeli annual tax return (Doch Mas Hachnasa).

**How the foreign tax credit works:** The US withholds 25% on your dividends under the treaty. Israel taxes investment income at 25%. Because you already paid 25% to the US, you receive a foreign tax credit in Israel - meaning you generally do not pay double tax on dividends.

**Capital gains:** Profits from selling stocks have no US withholding but are taxable in Israel at 25%. Report these on your Israeli tax return.

Key documents to keep:

-   Your IBKR annual statement (available in the Client Portal under Reports)
-   The 1042-S form (Foreign Person's US Source Income) - issued by IBKR each January for the prior tax year - Records of all buy and sell transactions

Tip: If your foreign investment income is significant, consider working with an Israeli accountant (roa'e cheshbon) who specializes in foreign investments. The cost is usually worth it for portfolios above $50,000.

## **Common Questions from Israeli Investors**

### **Do I need to declare my IBKR account to the Bank of Israel?**

There is no requirement to notify the Bank of Israel simply for opening a foreign brokerage account. However, you must report foreign assets and income to the Israeli Tax Authority as part of your annual tax obligations.

### **Can I use my Israeli credit card to fund my IBKR account?**

Generally no - credit card funding is not available for international brokerage accounts. Wire transfer is the standard method.

### **What happens if the shekel weakens against the dollar?**

Currency fluctuations affect your returns when measured in ILS. If the USD strengthens against the ILS, your US investments are worth more in shekel terms when you convert back. Many Israeli investors view their US holdings partly as a natural USD hedge.

### **What is the minimum amount to start?**

IBKR has no minimum deposit. However, to avoid the monthly inactivity fee, aim to either generate at least $10/month in commissions or grow your account to $100,000+. For beginners, starting with $1,000 to $5,000 is reasonable.

## **Israeli Bank Wire Transfers: Which Banks Work Best**

Not all Israeli banks handle international wire transfers equally:

**Bank Hapoalim and Bank Leumi:** Both support international wire transfers online. Fees are typically 30 to 80 ILS plus correspondent fees.

**Discount Bank and Mizrahi-Tefahot:** Also support international wires, though a branch visit may be required for first-time transfers.

**Digital banks (Pepper, etc.):** Check directly with your bank regarding international wire transfer capabilities, as these vary.

Tip: Call your bank before initiating your first international wire to confirm the process and exact fee schedule. Some banks require you to pre-register an international beneficiary account before wires can be sent online.

## **Summary: Your Step-by-Step Checklist**

-   Open IBKR account online (20 to 40 minutes)
-   Upload passport and proof of address
-   Complete W-8BEN form (enter Teudat Zehut number, select Israel, 25% rate)
-   Wait for account approval (1 to 3 business days)
-   Initiate wire transfer from Israeli bank to IBKR
-   Convert ILS to USD inside IBKR at interbank rate
-   Download IBKR Mobile app
-   Set up a [multi-currency account](/us-investing/multi-currency-investment-accounts/) to minimize FX costs
-   Place first trade using a Limit Order
-   Save IBKR annual statement and 1042-S for Israeli tax return

**Financial Disclaimer**

_The content on GetGlobalYields.com is for informational and educational purposes only and does not constitute financial, investment, or tax advice. Tax laws, broker terms, and regulatory requirements change over time. Always consult a licensed Israeli tax professional and verify current broker requirements before opening an account._

---

*Sources: US-Israel Income Tax Treaty (1975) and 1993 Protocol; IRS treaty text (irs.gov/pub/irs-trty/israel.pdf); Joint Committee on Taxation explanation of the 1993 Protocol; PwC Israel - Corporate Withholding Taxes (2026); IRS Publication 515 (2026).*
