---
slug: how-to-invest-in-us-stocks-from-thailand
title: "How to Invest in US Stocks from Thailand (2026 Guide)"
description: "How to Invest in US Stocks from Thailand: broker options, W-8BEN, the 15% treaty rate, and the remittance rule that defers tax until you bring money home."
pubDate: 2026-08-12
updatedDate: 2026-08-12
author: "Tzion Sigron"
categories: ["US Investing"]
tags:
  - "invest in US stocks from Thailand"
  - "Thailand ETF investing 2026"
  - "Interactive Brokers Thailand"
  - "IBKR Thailand"
  - "eToro Thailand"
  - "W-8BEN Thailand"
  - "Thailand remittance rule"
  - "best broker Thailand"
heroImage: "/images/blog/us-investing/how-to-invest-in-us-stocks-from-thailand.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: false
readingTime: "10 min read"
featured: false
---

Since January 1, 2024, Thailand only taxes foreign-source income - including US dividends and capital gains - when that income is actually brought into the country. Leave it in a US brokerage account, and it is simply not in scope for Thai tax yet, no matter how much has accumulated. That single rule shapes how a Thailand-based investor should think about US stocks more than the treaty rate does.

This guide covers what you can buy, the treaty's 15% dividend rate, and exactly what the remittance rule means in practice.

Everything here is verified from official sources for 2026.

---

<!-- ADSENSE PLACEHOLDER: TOP OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: HEADER_BANNER] -->

---

## Meet Nicha

Nicha is 29, lives in Bangkok, and works in marketing. She has THB 500,000 (about $14,000) to invest and has heard Thai tax law changed recently for people with money abroad. She is not sure exactly what changed or what it means for a US brokerage account she is thinking about opening. The short version: the change works in her favor, as long as she understands the timing rule behind it.

---

## Step 1: Which US Funds Reach Thailand

Thailand is not an EEA member, which is why the PRIIPs barrier facing European investors does not arise. **Nicha can buy VOO, VTI, and QQQ directly** through a broker offering US market access.

---

## Step 2: What the Thailand Treaty Gives You

The US-Thailand tax treaty (1996) caps US withholding on dividends paid to Thai resident individuals at **15%** for portfolio investors, claimed with Form [W-8BEN](/taxes/w8ben-form-non-us-investors/).

| Income Type | Default US Rate | Treaty Rate (Portfolio) |
|---|---|---|
| Dividends | 30% | **15%** |
| Capital gains (securities) | Generally not US-taxable for non-residents | Taxable by both countries under the treaty, though non-resident aliens generally face no US capital gains tax under separate domestic law |

The treaty stays theoretical until the form is filed. Nicha checks her first dividend statement to confirm 15%, not 30%, was withheld.

For the full treaty mechanics, see our US-Thailand tax treaty guide.

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE] -->

---

## Step 3: The Remittance Rule - Taxed Only When You Bring It Home

This is the detail that actually matters most for Nicha's planning.

Thai tax residents (broadly, anyone present in Thailand more than 180 days a year) are taxed on foreign-source income earned from **January 1, 2024 onward** only when that income is **remitted into Thailand** - whether in the same year it was earned or any later year.

**What this means concretely:** dividends and capital gains that Nicha leaves in her US brokerage account - reinvested, held as cash, or simply untouched - are not currently subject to Thai tax. The tax obligation arises specifically when she transfers the funds into Thailand, at which point the remitted amount becomes assessable income for that tax year.

**What this is not:** a permanent exemption. It is a timing rule. Money brought into Thailand in a later year is still taxable then, even if it represents gains realized years earlier - which rewards deliberate timing (remitting during a lower-income year, for example) rather than eliminating the liability altogether.

**Documentation matters more here than in most countries.** Because the rule turns on when money crosses into Thailand and what income it represents, clear records - brokerage statements showing when gains and dividends were realized, and bank records showing when and how much was remitted - are essential to calculating what is actually taxable in a given year.

**This also creates a genuine, deliberate planning opportunity that doesn't exist in most countries covered on this site.** An investor with a large capital gain who plans a lower-income year in the future (a career break, retirement, or similar) could reasonably time a remittance to that specific year, when Thailand's progressive tax rates would apply a lower marginal rate to the remitted amount than they would in a peak-earning year. This is a legitimate use of the timing rule as written, not an aggressive interpretation - though it requires genuine planning discipline and accurate record-keeping to execute correctly, and shouldn't be attempted without confirming the specifics with a Thai tax advisor given how consequential getting the calculation wrong could be.

---

## Step 4: The W-8BEN Step for Thailand Residents

Form W-8BEN goes to Nicha's broker and brings her US dividend withholding down from the 30% default to the treaty's 15%. It is typically completed during account opening and expires after three years.

---

## Step 5: The Broker Decision in Thailand

**Interactive Brokers (IBKR)** and **eToro** each accept Thai residents. [See our full IBKR review →](/best-brokers/interactive-brokers-review-2026-the-best-broker-for-international-investors/) · [See our full eToro review →](/best-brokers/etoro-review-2026/)

---

<!-- ADSENSE PLACEHOLDER: MID-ARTICLE 2 -->
<!-- [ADSENSE_UNIT_ID: MID_CONTENT_RECTANGLE_2] -->

---

## Step 6: What Nicha's Portfolio Looks Like in Practice

**Broker:** Interactive Brokers - lower running costs on a multi-year holding.

**Portfolio allocation:**
- 80% VOO (S&P 500, bought directly)
- 20% QQQ (Nasdaq-100, bought directly)
- Dividends are reinvested inside the US account rather than remitted, which keeps the timing rule working in Nicha's favour instead of against her
- W-8BEN filed and confirmed active (15% withholding on her dividend statement)

**Annual tax situation:**
- 15% US withholding on dividends
- No Thai tax owed on dividends or gains left in the US account
- Keeps brokerage and bank records to track exactly what she remits and when, so any future transfer to Thailand is correctly taxed only on the amount and timing that applies

She lets her portfolio compound in the US account and plans to remit specific amounts to Thailand deliberately, in years that make sense for her overall tax picture, rather than automatically transferring dividends as they arrive.

---

<!-- ADSENSE PLACEHOLDER: NEAR END OF ARTICLE -->
<!-- [ADSENSE_UNIT_ID: BOTTOM_CONTENT_RECTANGLE] -->

---

## Thailand: Avoidable Mistakes

**Assuming the remittance rule is a permanent exemption.** It is not - it defers tax until money is actually brought into Thailand, not forever.

**Not keeping records of when income was realized versus remitted.** Without clear documentation, correctly calculating what is taxable in a given year becomes difficult.

**Forgetting W-8BEN.** Skip it and the rate stays at the 30% default rather than dropping to the treaty's 15%.

**Assuming this applies regardless of residency status.** The remittance-basis treatment applies specifically to Thai tax residents (180+ days present in a year) - confirm your status.

---

## How to Begin From Thailand

1. **Open a broker account.** IBKR or eToro, both confirmed to accept Thai residents.
2. **File your W-8BEN** during account opening.
3. **Buy VOO or QQQ directly** - the UCITS detour is an EU-only requirement.
4. **Set up a simple record-keeping habit** for tracking realized income versus any future remittance to Thailand.

---

*General material on Thailand - it does not account for your circumstances. Treaty rates are based on the US-Thailand Income Tax Convention (1996). Thailand's remittance-basis rule took effect January 1, 2024 and its application can be fact-specific - consult a qualified Thai tax advisor for advice on your specific situation.*

---

<!-- AFFILIATES PLACEHOLDER: BROKER CTA SECTION -->
<!-- Place immediately below the disclaimer -->
<!-- [AFFILIATE_UNIT: BROKER_COMPARISON_TABLE_THAILAND] -->
<!-- Anchor text: "Compare the best brokers for Thailand-based investors in 2026 - fees, account access, and ETF availability." -->
<!-- Link to: /best-brokers/best-brokers-international-investors-2026/ (no Thailand-specific page exists yet) -->

---

## What Readers Ask About Thailand

**Can I buy VOO and QQQ directly as a Thailand-based investor?**
Yes. The PRIIPs rule that limits European buyers does not apply in Thailand, so your broker's full US-listed menu is open.

**What's the US withholding rate on my dividends?**
15%, under the US-Thailand tax treaty, once Form W-8BEN is filed with your broker. Without it, the default 30% applies.

**Do I owe Thai tax on US dividends and capital gains I don't bring into Thailand?**
No, not currently. Since January 1, 2024, Thailand taxes foreign-source income only when it is remitted into the country - income left in a US brokerage account is not currently in scope.

**Is the remittance rule a permanent tax exemption?**
No. It is a timing deferral. Money brought into Thailand in a later year is taxable in the year it is remitted, regardless of when it was originally earned.

**Which brokers accept Thailand-based residents?**
Interactive Brokers and eToro are both confirmed to accept Thai residents for account opening.

---

*Sources: US-Thailand Income Tax Convention (1996); IRS treaty text; JCT explanation of the treaty; IRS Publication 515 (2026).*
