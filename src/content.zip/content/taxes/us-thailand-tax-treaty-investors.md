---
slug: us-thailand-tax-treaty-investors
title: "US-Thailand Tax Treaty for Investors: The Remittance Rule Explained (2026)"
description: "US-Thailand tax treaty guide for individual investors. The 15% dividend rate, and how Thailand's 2024 remittance-basis rule means US investment income isn't taxed by Thailand until you actually bring it into the country."
pubDate: 2026-10-07
updatedDate: 2026-08-25
author: "Tzion Sigron"
categories: ["Taxes"]
tags:
  - "us thailand tax treaty"
  - "thailand investor us stocks"
  - "interactive brokers thailand"
  - "etoro thailand"
  - "w-8ben thailand"
heroImage: "/images/blog/taxes/us-thailand-tax-treaty-investors.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: true
readingTime: "9 min read"
featured: false
seo:
  metaTitle: "US-Thailand Tax Treaty: The Remittance Rule Explained (2026)"
  metaDescription: "Under the US-Thailand tax treaty, dividends are withheld at 15% rather than 30%. Thailand's 2024 remittance-basis rule means US investment income isn't taxed."
  ogTitle: "US-Thailand Tax Treaty: The Remittance Rule Explained (2026)"
  ogDescription: "Under the US-Thailand tax treaty, dividends are withheld at 15% rather than 30%. Thailand's 2024 remittance-basis rule means US investment income isn't taxed."
  ogImage: "/images/blog/taxes/us-thailand-tax-treaty-investors.webp"
  twitterCard: "summary_large_image"
schema:
  type: "article"
  headline: "US-Thailand Tax Treaty: The Remittance Rule Explained (2026)"
  description: "Under the US-Thailand tax treaty, dividends are withheld at 15% rather than 30%. Thailand's 2024 remittance-basis rule means US investment income isn't taxed."
  author: "Tzion Sigron"
  datePublished: "2026-10-07"
  dateModified: "2026-08-25"
  image: "/images/blog/taxes/us-thailand-tax-treaty-investors.webp"
  mainEntityOfPage: "https://getglobalyields.com/taxes/us-thailand-tax-treaty-investors"
---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Top of article, before content
     Recommended: Responsive AdSense display unit or broker affiliate banner
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

Since January 1, 2024, Thailand taxes its residents on foreign-source income - which includes US dividends and capital gains - only when that income is actually **brought into Thailand**, in the year it's earned or any later year. Leave it in your US brokerage account, and Thailand's remittance-basis rule means it simply isn't in scope for Thai tax yet, regardless of how much you've earned. This is one of the more investor-favorable domestic rules covered anywhere in this series, and it shapes this guide more than the treaty rate does.

The treaty side is standard: the US-Thailand tax treaty caps dividend withholding at **15%** for individual portfolio investors, claimed with [W-8BEN](/taxes/w8ben-form-non-us-investors/). This guide covers that rate and the remittance rule in detail, since understanding exactly what counts as "bringing money into Thailand" is where the real planning value sits.

---

## The Remittance Rule: Taxed Only When You Bring It Home

Thailand's tax residents - broadly, anyone present in the country more than 180 days in a calendar year - are taxed on Thai-source income as usual, but for **foreign-source income earned from January 1, 2024 onward**, Thai tax applies only to the portion **remitted into Thailand**, whether that happens in the same year the income was earned or in any subsequent year.

**What this means for US stock investors specifically:** dividends and capital gains that stay in a US brokerage account - reinvested, held as cash, or simply left alone - are not currently subject to Thai tax. The tax obligation arises specifically when funds are transferred into Thailand, at which point the remitted amount becomes assessable Thai income for that tax year.

**What this doesn't mean:** it's not a permanent exemption - it's a timing rule. Money you eventually bring into Thailand is taxable when remitted, even if it represents gains from several years earlier. This rewards deliberate timing (bringing money in during a lower-income year, for example) rather than eliminating the liability altogether.

**Documentation matters here more than in most countries.** Because the remittance rule turns on when money crosses into Thailand and what income it represents, keeping clear records - brokerage statements showing when gains and dividends were realized, and bank records showing when and how much was remitted - is essential to correctly calculating what's taxable in a given year rather than assuming the full remitted amount or the full realized amount applies uniformly.

---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Mid-article, after remittance rule section
     Recommended: Contextual AdSense unit or broker comparison affiliate
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

---

## Halving the Withholding: Thailand's 15%

| Income Type | Default US Rate | Treaty Rate (Portfolio) | Direct Corporate (10%+) |
|---|---|---|---|
| Dividends | 30% | **15%** | **10%** |
| Capital gains (securities) | Generally not US-taxable for non-residents | Taxable by both countries under the treaty | Taxable by both countries under the treaty |

*Sources: US-Thailand Income Tax Convention (1996); IRS treaty text; JCT explanation of the treaty.*

The form on file is the whole difference between default and treaty withholding. With no form on file the full 30% applies from the very first dividend.

**One structural difference from most other treaties in this series:** the US-Thailand treaty's capital gains article allows both countries to potentially tax gains, rather than the residence-only structure common elsewhere. In practice, non-resident aliens generally still don't face US capital gains tax under separate domestic law (IRC §871), so this is less consequential than it might first appear - but it's worth understanding the treaty text doesn't automatically grant the same residence-only exclusivity that, say, the UK or German treaty does.

---

## Where Thailand Residents Can Open an Account

Coverage for Thailand comes from Interactive Brokers and eToro. Verify what the broker asks for today - eligibility rules for individual countries shift without announcement.

---

## Working Through It from Thailand

**What a Thai investor needs to have covered:**
- [ ] Confirm W-8BEN is on file with your broker; verify 15%, not 30%, on dividend statements
- [ ] Track which gains and dividends have been realized versus remitted into Thailand - only remitted amounts are currently taxable under the post-2024 rule
- [ ] Keep clear brokerage and bank records to support the timing and composition of any remittance
- [ ] Remember the remittance rule is a timing deferral, not a permanent exemption - money brought into Thailand in a later year is still taxable then
- [ ] Confirm your Thai tax residency status (180+ days) since the remittance-basis treatment applies specifically to tax residents
- [ ] Verify current onboarding requirements with Interactive Brokers or eToro yourself

---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Before conclusion
     Recommended: Broker affiliate banner or responsive AdSense unit
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

---

## Thailand: The Balance of It

The treaty rate is standard - 15% on dividends, claimed with W-8BEN, nothing further to optimize on the US side. The real planning lever for a Thai resident is the 2024 remittance rule: US investment income left in a US brokerage account isn't currently taxed by Thailand at all, and only becomes taxable in the year it's actually brought into the country. That timing flexibility is worth more to most investors in this guide than the treaty rate itself, and it's a genuinely distinctive feature relative to most other countries covered in this series, which tax worldwide income as it's earned rather than as it's remitted.

---

*This is general information about investing from Thailand, not advice on your own position. Treaty rates are based on the US-Thailand Income Tax Convention (1996). Thailand's remittance-basis rule for foreign-source income took effect January 1, 2024, and its application can be fact-specific - always consult a qualified Thai tax advisor for advice on your specific remittance and residency situation.*

*Sources: US-Thailand Income Tax Convention (1996); IRS Publication 515 (2026); JCT explanation of the US-Thailand tax treaty; PwC Thailand and PwC US Tax Summaries - Withholding Taxes (2026); taxesforexpats.com - Thailand tax preparation guide (2026).*

## Related Guides

- [US Dividend Withholding Tax for Foreign Investors](/taxes/taxes-us-dividends-foreign-investors/)
- [PFIC Rules for International Investors](/taxes/pfic-rules-international-investors/)
- [W-8BEN Form Complete Guide for International Investors](/taxes/w8ben-form-non-us-investors/)
- [Interactive Brokers Singapore: US Stock Tax Guide](/taxes/us-singapore-tax-treaty-investors/)
- [Best Brokers for International Investors](/best-brokers/best-brokers-international-investors-2026/)
