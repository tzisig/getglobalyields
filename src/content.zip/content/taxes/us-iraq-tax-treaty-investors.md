---
slug: us-iraq-tax-treaty-investors
title: "US-Iraq Tax Treaty for Investors: Check Your Bank First (2026)"
description: "Iraq investor guide to US stock taxation. No US-Iraq tax treaty exists, so full 30% US dividend withholding applies. US Federal Reserve restrictions on specific Iraqi banks' dollar access - not sanctions on Iraq - make checking your bank's status essential."
pubDate: 2026-10-08
updatedDate: 2026-08-26
author: "Tzion Sigron"
categories: ["Taxes"]
tags:
  - "us iraq tax treaty"
  - "iraq investor us stocks"
  - "interactive brokers iraq"
  - "etoro iraq"
  - "iraqi dinar dollar auction"
heroImage: "/images/blog/taxes/us-iraq-tax-treaty-investors.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: true
readingTime: "10 min read"
featured: false
seo:
  metaTitle: "US-Iraq Tax Treaty: Check Your Bank First (2026)"
  metaDescription: "With no US-Iraq tax treaty, US dividends face the full 30% withholding. Federal Reserve restrictions on specific Iraqi banks' dollar access make checking."
  ogTitle: "US-Iraq Tax Treaty: Check Your Bank First (2026)"
  ogDescription: "With no US-Iraq tax treaty, US dividends face the full 30% withholding. Federal Reserve restrictions on specific Iraqi banks' dollar access make checking."
  ogImage: "/images/blog/taxes/us-iraq-tax-treaty-investors.webp"
  twitterCard: "summary_large_image"
schema:
  type: "article"
  headline: "US-Iraq Tax Treaty: Check Your Bank First (2026)"
  description: "With no US-Iraq tax treaty, US dividends face the full 30% withholding. Federal Reserve restrictions on specific Iraqi banks' dollar access make checking."
  author: "Tzion Sigron"
  datePublished: "2026-10-08"
  dateModified: "2026-08-26"
  image: "/images/blog/taxes/us-iraq-tax-treaty-investors.webp"
  mainEntityOfPage: "https://getglobalyields.com/taxes/us-iraq-tax-treaty-investors"
---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Top of article, before content
     Recommended: Responsive AdSense display unit or broker affiliate banner
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

Iraq itself is not under US sanctions - it's not on the list of comprehensively embargoed countries, and there's nothing preventing an ordinary Iraqi resident from opening or funding a US brokerage account as a matter of sanctions law. **But a real, separate issue affects the practical side of this:** since 2019, and updated as recently as **February 2026**, the US Federal Reserve Bank of New York and Treasury have progressively restricted specific Iraqi banks from accessing the dollar auction and wire-transfer systems used to source US currency - a measure aimed at curbing money laundering and dollar smuggling to Iran, not at Iraq or Iraqis generally. If your bank is on that restricted list, moving dollars internationally through it becomes far harder even though nothing about you personally is restricted.

There's also no US-Iraq income tax treaty, so full 30% US withholding applies regardless. This guide covers both.

---

## Check Your Bank's Status First

The Central Bank of Iraq's dollar and wire auctions are the main channel Iraqi banks use to source US dollars. Since 2019, the New York Fed has progressively barred a growing list of Iraqi banks from this system - roughly two dozen by some counts - specifically to prevent bad actors from laundering dollars or funneling them to Iran in violation of US sanctions on that country. **The Central Bank of Iraq updated its list of dollar-restricted banks again on February 26, 2026.**

**This has had real, documented economic effects** beyond the banks directly involved: a widening gap between the official and parallel-market dinar exchange rate, higher import costs, and broader inflationary pressure, according to reporting on the policy's impact.

**What this means practically:** before assuming you can wire dollars from an Iraqi bank account to fund a foreign brokerage account, **confirm directly with your specific bank whether it currently has unrestricted dollar access** - this list changes periodically, and being on it doesn't reflect anything about you as a customer, just about that institution's current standing with US correspondent banking rules.

---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Mid-article, after banking section
     Recommended: Contextual AdSense unit or broker comparison affiliate
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

---

## No Treaty With Iraq: The Full 30%

No income tax treaty links the US and Iraq. Dividends from US companies are withheld at the full **30% statutory rate** before an Iraqi resident sees them - and, as the rest of this guide covers, the tax is rarely the binding constraint anyway.

**Filing Form [W-8BEN](/taxes/w8ben-form-non-us-investors/) is still worth doing.** The rate holds steady - the gain is correct non-US classification and no backup withholding.

---

## Iraq's Domestic Tax: 15% Flat, With a Funding-Source Condition

Iraq applies a flat **15%** personal income tax rate, and capital gains are included in taxable income at the same 15% - no separate, higher, or lower capital gains category. **Dividends already taxed at the corporate level aren't taxed again** when distributed to the shareholder, avoiding domestic double taxation on that layer.

**The condition worth understanding on foreign-source income:** income realized outside Iraq by residents - including investment returns and gains from trading securities - is described as taxable **if it arises from funds and deposits held in Iraq**. This scoping detail suggests the source of the capital used to invest matters to how Iraq characterizes the resulting foreign income. **Confirm with an Iraqi tax advisor how this applies to your specific situation** - particularly whether funds sourced or held domestically before being invested abroad changes the tax treatment compared to income earned and invested entirely outside Iraq.

---

## Getting Set Up as an Iraq Investor

Interactive Brokers and eToro are the two brokers most often cited as accepting Iraqi residents, but we were not able to verify either policy directly - check with the broker before assuming eligibility. In any case the funding step, not account opening, is where the bank-restriction question above actually bites.

---

## Tidying Up the Iraq Details

**Working through it as an Iraqi resident:**
- [ ] Confirm directly with your bank whether it currently has unrestricted access to the US dollar auction/wire system before planning an international transfer
- [ ] File W-8BEN once the account is funded - it changes nothing about the 30%, but leaves the account properly documented rather than exposed to backup withholding
- [ ] Expect 30% US withholding on every dividend payment, with no treaty-based reduction available
- [ ] Budget for Iraq's flat 15% domestic tax on both dividends and capital gains
- [ ] Confirm with an Iraqi tax advisor how the "funds held in Iraq" condition applies to your foreign-source investment income
- [ ] Re-check account-opening requirements with the broker directly before you apply

---

<!-- ADSENSE / AFFILIATE PLACEHOLDER
     Position: Before conclusion
     Recommended: Broker affiliate banner or responsive AdSense unit
     Replace this comment block with your AdSense tag or affiliate banner HTML -->

---

## What All of This Means from Iraq

There's no US-Iraq tax treaty, so the full 30% US withholding applies with no reduction available - the W-8BEN is worth filing anyway, for status rather than savings. Iraq's domestic side is comparatively simple: a flat 15% on dividends and capital gains alike, with a funding-source nuance worth confirming with an advisor. The single most practical thing to check before anything else is whether your specific Iraqi bank currently has US dollar access - a real, actively-updated restriction that has nothing to do with Iraq being sanctioned and everything to do with which individual banks currently meet US correspondent banking standards.

---

*Orientation on investing from Iraq, not personalised tax or legal advice. There is no US-Iraq income tax treaty. The list of Iraqi banks restricted from US dollar access changes periodically - confirm current status directly with your bank. Iraq's domestic tax rules are set by Iraqi law and can change. An Iraqi tax professional should look at this against your real position.*

*Sources: Iraq Business News - Iraqi Banks Restricted from US Dollar Transactions: Full List (Amended, 2026); LSE Middle East Centre - The Empire Strikes Back: Trump 2.0 and Iraq's Dollar Accounts at the Federal Reserve; The New Arab - Iraq Central Bank Bars Local Banks from US$ Transactions; PwC Iraq - Individual Foreign Tax Relief and Tax Treaties and Taxes on Personal Income (2026); IRS Publication 515 (2026).*

## Related Guides

- [PFIC Rules for International Investors](/taxes/pfic-rules-international-investors/)
- [US Dividend Withholding Tax for Foreign Investors](/taxes/taxes-us-dividends-foreign-investors/)
- [US-Egypt Tax Treaty for Investors](/taxes/us-egypt-tax-treaty-investors/)
- [US-Jordan Tax Treaty for Investors](/taxes/us-jordan-tax-treaty-investors/)
- [W-8BEN Form Complete Guide for International Investors](/taxes/w8ben-form-non-us-investors/)
