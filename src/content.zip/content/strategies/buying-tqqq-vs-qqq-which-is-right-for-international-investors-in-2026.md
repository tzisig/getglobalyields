---
slug: buying-tqqq-vs-qqq-which-is-right-for-international-investors-in-2026
title: "TQQQ vs QQQ: Which Is Right for Non-US Investors in 2026?"
description: "Compare TQQQ vs QQQ for international investors. Learn about volatility decay, taxes, risks, and when to use leveraged ETFs safely."
pubDate: 2026-04-05
updatedDate: 2026-05-12
author: "Tzion Sigron"
categories: ["Strategies"]
tags:
  - "volatility decay explained"
  - "tqqq strategy"
  - "investing in us from abroad"
  - "best etf for international investors"
  - "ibkr non us investors"
  - "tqqq vs qqq"
  - "leveraged etf risks"
heroImage: "/images/blog/strategies/buying-tqqq-vs-qqq-which-is-right-for-international-investors-in-2026.webp"
heroImageWidth: 840
heroImageHeight: 560
draft: false
readingTime: "10 min read"
featured: false
products: ["TQQQ", "QQQ"]
---

If you're investing in US markets from outside the US, you've probably come across QQQ and TQQQ. They both track the Nasdaq-100. They are not the same investment.

One is built for long-term growth. The other is a high-risk trading tool that can multiply gains - or destroy capital fast.

I used TQQQ myself during a recovery phase after a 70% portfolio drawdown. Read the full breakdown: [Case Study: From -70% to +250%](/case-study/from-minus-70-to-plus-492k-real-tqqq-recovery-case-study/)

<!-- AdSense Placement -->

## **What Are QQQ and TQQQ?**

**QQQ (Invesco QQQ Trust)** tracks the Nasdaq-100 index, giving exposure to major tech companies like Apple, Microsoft, Nvidia, and Amazon. It carries no leverage, charges a 0.20% expense ratio, and is built for long-term investing - this is the standard way to invest in US tech.

**TQQQ (ProShares UltraPro QQQ)** is a leveraged ETF designed to deliver 3x the daily return of the Nasdaq-100, resetting that leverage every trading day. It charges a 0.82% expense ratio and is built for short-term, tactical use. TQQQ is not a "faster QQQ" - it behaves differently because of its structure, which is exactly what the rest of this guide covers.

## **The Critical Difference: Volatility Decay and Path Dependency**

Most investors misunderstand this.

### **Volatility Decay (Beta Slippage)**

In a volatile or sideways market, TQQQ loses value over time - even if the index ends flat.

**Example:**

- Day 1: Nasdaq +5% → TQQQ +15%
- Day 2: Nasdaq -5% → TQQQ -15%

**Result:**

- Nasdaq: ~-0.25%
- TQQQ: ~-2.25%

Over time, this compounds and erodes capital.

### **Path Dependency (Critical Concept)**

TQQQ returns depend on how the market moves, not just where it ends.

Two identical outcomes in QQQ can produce very different results in TQQQ depending on volatility along the way.

| Day | Nasdaq | QQQ | TQQQ |
|---|---|---|---|
| Start | - | $10,000 | $10,000 |
| Day 1 | +8% | $10,800 | $12,400 |
| Day 2 | -8% | $9,936 | $9,424 |
| Day 3 | +8% | $10,731 | $11,686 |
| Day 4 | -8% | $9,872 | $8,881 |
| Day 5 | +1% | $9,971 | $9,148 |

*Nasdaq down only ~0.3% over 5 days - but TQQQ lost ~8.5%. Same index, very different outcome.*

This is why long-term holding of TQQQ in unstable markets can fail - even if the index recovers.

## **Side-by-Side Comparison**

| Feature | QQQ | TQQQ |
|---|---|---|
| Leverage | 1x | 3x Daily |
| Expense Ratio | 0.20% | 0.82% |
| Risk Level | Moderate | Extreme |
| Volatility Decay | No | Yes (High) |
| Max Drawdown (2022) | ~-35% | ~-80%+ |
| Strategy | Long-term | Tactical |

<!-- AdSense Placement -->

## **Tax Considerations for Non-US Investors**

### **Dividend Withholding**

- Typically 30% for non-US investors
- Reduced via tax treaties (e.g., [Israel](/taxes/us-israel-tax-treaty-explained-capital-gains-dividends-2026/), EU)
- Requires [W-8BEN](/taxes/w8ben-form-non-us-investors/)

The default [US withholding rate](/taxes/taxes-us-dividends-foreign-investors/) is 30% - but most countries have a tax treaty that reduces this.

Check your country's rate:- <a href="https://www.irs.gov/individuals/international-taxpayers/tax-treaty-tables" target="_blank" rel="noopener noreferrer">IRS Tax Treaty Tables</a>. For a full breakdown of TQQQ-specific tax rules, see our [TQQQ Tax Guide for International Investors](/taxes/tqqq-tax-international-investors/). Also see our [Wheel Strategy on TQQQ](/options-income/wheel-strategy-tqqq/) for options-based approaches.

### **Capital Gains**

- Usually not taxed by the US
- Taxed in your home country

The key difference: QQQ generates fewer taxable events since it's typically held long-term, while TQQQ's frequent trading creates more tax exposure.

### **Efficiency Insight**

TQQQ's lower dividend yield does mean less withholding impact - but that's offset by the added complexity of higher turnover.

## **The Fee and Withholding Gap, Costed**

The two funds are usually compared on volatility alone, but they also differ on two recurring costs that compound quietly over a decade.

**Expense ratio.** QQQ charges **0.20%**; TQQQ charges **0.82%** - roughly four times as much. On a $50,000 position that is $100 a year against $410, and the gap widens as the position grows. Over ten years, before any market movement, TQQQ's fee alone consumes several thousand dollars more.

**Dividend withholding.** QQQ distributes more than TQQQ, so a non-US investor meets the withholding more often holding QQQ. On a portfolio throwing off $500 of QQQ dividends a year at the 30% default, that is $150 withheld annually - reduced to $75 in a 15% treaty country with W-8BEN filed.

| | QQQ | TQQQ |
|---|---|---|
| Expense ratio | 0.20% | 0.82% |
| Annual fee on $50,000 | $100 | $410 |
| Dividend exposure | Higher - more withholding events | Lower - little to withhold |

**The two costs pull in opposite directions**, which is why neither fund is cleanly "cheaper" for an international investor. QQQ costs less to hold and more to receive income from; TQQQ costs far more to hold and distributes little. For a long-horizon investor the expense ratio dominates, because it is charged on the whole position every year regardless of what the market does - while withholding only ever touches the distribution.

---

## **When QQQ Makes Sense**

Choose QQQ if:

- You invest long-term (5–10 years)
- You prefer a passive strategy
- You use DCA
- You don't monitor markets daily

## **When TQQQ Can Make Sense**

TQQQ works only under specific conditions:

- After major market drops (50%+)
- Strong trending environments
- Clear recovery thesis
- Active management

*It should always be a small part of your portfolio.*

In my own case, combining TQQQ with an [options strategy](/options-income/selling-covered-calls-tqqq/) during a recovery phase turned this structural risk into a significant advantage - [you can read the full breakdown in the case study.](/case-study/from-minus-70-to-plus-492k-real-tqqq-recovery-case-study/)

## **When to Avoid TQQQ**

Avoid if:

- Market near highs
- Low volatility environment
- You need stability
- You can't handle large drawdowns

## **The Reality Most Investors Miss**

TQQQ is not an investment - it's a tool. Used correctly, it's powerful. Used incorrectly, it's destructive.

## **Which One Should You Choose?**

For most non-US investors, QQQ is the better default. TQQQ is for experienced users with specific timing conviction and controlled exposure - not a default choice.

<!-- AdSense Placement -->

## **Getting Started (Non-US Investors)**

Before investing, you need the right broker. Key requirements:

- Access to US markets
- Low fees
- Reliable execution
- Options support

For managing leveraged ETF risk, read our [Risk Management Guide](/strategies/risk-management-leveraged-etf-investors-2026/). For the long-term outlook, see [TQQQ Long-Term Outlook](/strategies/tqqq-long-term-outlook/). Use the [Broker Finder](/resources/broker-finder/) and [Broker Calculator](/resources/broker-calculator/) to compare costs.

We recommend IBKR for most non-US investors [here's our full review.](/best-brokers/interactive-brokers-review-2026-the-best-broker-for-international-investors/)

## **Final Takeaway**

QQQ and TQQQ track the same index, but behave very differently: QQQ delivers long-term compounding, while TQQQ delivers leveraged exposure with structural risk.

**The biggest mistake isn't choosing the wrong ETF. It's using the right one at the wrong time.**

---

*This is an overview of TQQQ vs QQQ, not advice. The figures move, and no guide substitutes for advice on your own holdings.*